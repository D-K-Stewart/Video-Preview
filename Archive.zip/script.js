console.log("page loaded...");

function playVid(element) {
    element.play("rock")
}
function pauseVid(element) {
    element.pause("rock")
}